import React, { useState } from "react";
import NoteForm from "./components/NoteForm";
import NoteList from "./components/NoteList";

function App() {
  const [reload, setReload] = useState(false);
  const triggerReload = () => setReload(!reload);

  return (
    <div className="App" style={{ padding: "20px", fontFamily: "sans-serif" }}>
      <h1>🛡️ Privacy-Focused Notes</h1>
      <NoteForm onSave={triggerReload} />
      <NoteList key={reload} />
    </div>
  );
}

export default App;