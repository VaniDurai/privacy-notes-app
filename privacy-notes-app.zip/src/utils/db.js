import { openDB } from "idb";

const DB_NAME = "encryptedNotes";
const STORE_NAME = "notes";

export const getDB = async () =>
  openDB(DB_NAME, 1, {
    upgrade(db) {
      db.createObjectStore(STORE_NAME, { keyPath: "id", autoIncrement: true });
    },
  });

export const saveNote = async (note) => {
  const db = await getDB();
  await db.add(STORE_NAME, note);
};

export const getAllNotes = async () => {
  const db = await getDB();
  return await db.getAll(STORE_NAME);
};

export const deleteNote = async (id) => {
  const db = await getDB();
  await db.delete(STORE_NAME, id);
};