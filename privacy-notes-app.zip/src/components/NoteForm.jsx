import React, { useState } from "react";
import { encryptText } from "../utils/cryptoUtils";
import { saveNote } from "../utils/db";

export default function NoteForm({ onSave }) {
  const [text, setText] = useState("");

  const handleSave = async () => {
    const encrypted = encryptText(text);
    await saveNote({ content: encrypted });
    setText("");
    onSave();
  };

  return (
    <div>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Enter your note..."
        rows="5"
        cols="50"
      />
      <br />
      <button onClick={handleSave}>Save</button>
    </div>
  );
}